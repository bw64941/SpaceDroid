//package com.ironbrand.spacedroid.view;
//
//import java.util.Iterator;
//import java.util.LinkedList;
//
//import org.andengine.engine.handler.IUpdateHandler;
//import org.andengine.entity.modifier.MoveYModifier;
//import org.andengine.entity.modifier.ParallelEntityModifier;
//import org.andengine.entity.modifier.RotationModifier;
//import org.andengine.entity.modifier.ScaleModifier;
//import org.andengine.extension.physics.box2d.PhysicsConnector;
//import org.andengine.extension.physics.box2d.util.Vector2Pool;
//import org.andengine.extension.physics.box2d.util.constants.PhysicsConstants;
//
//import android.util.Log;
//
//import com.badlogic.gdx.math.Vector2;
//import com.ironbrand.spacedroid.GameActivity;
//import com.ironbrand.spacedroid.manager.ResourcesManager;
//
//public class GameLogic implements IUpdateHandler {
//
//    private static final String TAG = GameLogic.class.getName();
//    private LinkedList<Asteroid> enemyLinkedList = null;
//private LinkedList<Asteroid> enemiesToBeAdded = null;
//    private LinkedList<Alien> blocksLinkedList = null;
//    
//    private LinkedList<Alien> blocksToBeAdded = null;
//    private GameActivity baseGame = null;
//    private GameScene gameScene = null;
//    private GamePhysicsWorld gamePhysicsWorld = null;
//    private int score = 0;
//    private final int maxScore = 1000;
//    private int hitCount = 0;
//
//    public GameLogic(GameActivity baseGame, GameScene gameScene, GamePhysicsWorld gamePhysicsWorld) {
//	this.enemyLinkedList = new LinkedList<Asteroid>();
//	this.enemiesToBeAdded = new LinkedList<Asteroid>();
//	this.blocksLinkedList = new LinkedList<Alien>();
//	this.blocksToBeAdded = new LinkedList<Alien>();
//	this.baseGame = baseGame;
//	this.gameScene = gameScene;
//	this.gamePhysicsWorld = gamePhysicsWorld;
//	this.restart();
//    }
//
//    @Override
//    public void onUpdate(float pSecondsElapsed) {
//
//	Iterator<Asteroid> enemiesIterator = enemyLinkedList.iterator();
//	Asteroid enemy = null;
//	boolean hit = false;
//	boolean win = false;
//	boolean lose = false;
//
//	while (enemiesIterator.hasNext()) {
//	    enemy = enemiesIterator.next();
//	    if (enemy.getY() >= (ResourcesManager.getInstance().camera.getHeight() - enemy.getHeight())) {
//		GameActivity.getEnemyPool().recyclePoolItem(enemy);
//		enemiesIterator.remove();
//		continue;
//	    }
//
//	    if (enemy.collidesWith(baseGame.getPlayer())) {
//		Log.d(TAG, "Asteroid Collides with Spaceship");
//		GameActivity.getEnemyPool().recyclePoolItem(enemy);
//		enemiesIterator.remove();
//		hit = true;
//		hitCount++;
//		handleExplosion(enemy);
//		break;
//	    }
//
//	}
//
//	if (score >= maxScore) {
//	    win = true;
//	    hitCount = 0;
//	}
//
//	if (hit) {
//	    handleTargetHit();
//	}
//
//	if (win) {
//	    handleWin();
//	}
//
//	if (lose) {
//	    handleFail();
//	}
//
//	enemyLinkedList.addAll(enemiesToBeAdded);
//	enemiesToBeAdded.clear();
//	blocksLinkedList.addAll(blocksToBeAdded);
//	blocksToBeAdded.clear();
//    }
//
//    private void handleExplosion(Asteroid enemy) {
//	baseGame.getGameScene().getScoreDifference().setPosition(enemy.getX(), enemy.getY());
//	baseGame.getGameScene().getScoreDifference().setText("+" + 50);
//	baseGame.getGameScene().getScoreDifference().setVisible(true);
//	baseGame.getGameScene().getScoreDifference().registerEntityModifier(new ParallelEntityModifier(new RotationModifier(1.0f, 0, 360.0f), new ScaleModifier(1.0f, 0.5f, 1.0f)));
//	baseGame.getEnemyExplosionParticleSystem().getEnemyExplosionEmitter().setCenter(enemy.getX(), enemy.getY());
//	baseGame.getEnemyExplosionParticleSystem().setParticlesSpawnEnabled(true);
//    }
//
//    @Override
//    public void reset() {
//    }
//
//    /*
//     * Add enemy to scene
//     */
//    public void addTarget() {
//
//	Asteroid enemy = GameActivity.getEnemyPool().obtainPoolItem();
//	enemy.setPosition(enemy.getX_start(), enemy.getY_start());
//	MoveYModifier mod = new MoveYModifier(enemy.getRangeDuration(), enemy.getY(), ResourcesManager.getInstance().camera.getHeight() - enemy.getHeight());
//	enemy.registerEntityModifier(mod.deepCopy());
//
//	enemiesToBeAdded.add(enemy);
//    }
//
//    /*
//     * Updates score when target is hit.
//     */
//    private void handleTargetHit() {
//	score += 50;
//	baseGame.getGameScene().getScoreText().setText("Score: " + this.score);
//    }
//
//    /*
//     * Reset the scene
//     */
//    public void restart() {
//
//	baseGame.runOnUpdateThread(new Runnable() {
//
//	    @Override
//	    public void run() {
//		gameScene.detachChildren();
//		gameScene.attachChild(baseGame.getEnemyExplosionParticleSystem());
//		gameScene.attachChild(baseGame.getPlayer());
//		gamePhysicsWorld.registerPhysicsConnector(new PhysicsConnector(baseGame.getPlayer(), baseGame.getPlayer().getBody(), true, false));
//		baseGame.getGameScene().attachChild(baseGame.getBlock());
//		gamePhysicsWorld.registerPhysicsConnector(new PhysicsConnector(baseGame.getBlock(), baseGame.getBlock().getBlockBody(), true, false));
//		gameScene.attachChild(gameScene.getScoreText());
//		gameScene.attachChild(gameScene.getScoreDifference());
//		gameScene.getScoreDifference().setVisible(false);
//		gameScene.attachChild(baseGame.getPlayerAnchorSprite());
//		gameScene.attachChild(baseGame.getConnectionLine());
//		baseGame.getRevolveLine().setVisible(false);
//		gameScene.attachChild(baseGame.getRevolveLine());
//		Vector2 force = Vector2Pool.obtain(-50.0f, 0.0f);
//		baseGame.getPlayer().getBody().applyForce(force, baseGame.getPlayer().getBody().getWorldCenter());
//		Vector2Pool.recycle(force);
//		while (gamePhysicsWorld.getJoints().hasNext()) {
//		    gamePhysicsWorld.destroyJoint(gamePhysicsWorld.getJoints().next());
//		}
//		baseGame.getConnectionLine().setPosition(baseGame.getConnectionLine().getX1(), baseGame.getConnectionLine().getY1(),
//			(baseGame.getPlayer().getBody().getPosition().x - (baseGame.getPlayerTexture().getWidth() / 2)) * PhysicsConstants.PIXEL_TO_METER_RATIO_DEFAULT,
//			baseGame.getPlayer().getBody().getPosition().y * PhysicsConstants.PIXEL_TO_METER_RATIO_DEFAULT);
//		baseGame.getEnemyGenHandler().setTimerSeconds(1.0f);
//		baseGame.getConnectionLine().setVisible(true);
//	    }
//	});
//	gameScene.getScoreText().setText("Score: " + 0);
//	gameScene.getScoreDifference().setText("+" + 00);
//	this.score = 0;
//	hitCount = 0;
//	blocksLinkedList.clear();
//	blocksToBeAdded.clear();
//	enemiesToBeAdded.clear();
//	enemyLinkedList.clear();
//    }
//
//    /*
//     * Handle Game Over
//     */
//    private void handleWin() {
//	baseGame.win();
//    }
//
//    /*
//     * Handle Game Over
//     */
//    private void handleFail() {
//	baseGame.fail();
//    }
//
//    /**
//     * @return the hitCount
//     */
//    public int getHitCount() {
//	return hitCount;
//    }
//
//    /**
//     * @param hitCount
//     *            the hitCount to set
//     */
//    public void setHitCount(int hitCount) {
//	this.hitCount = hitCount;
//    }
//   // /*
    // * Flings player across the scene based on finger direction.
    // */
    // private boolean onFling(float originalX, float newX, float origianlY,
    // float newY) {
    // float c;
    // float sx = 0, sy = 0;
    // float x1 = originalX;
    // float y1 = origianlY;
    //
    // float x2 = newX;
    // float y2 = newY;
    //
    // float playerX = this.getX();
    // float playerY = this.getY();
    // Log.d(TAG, "FLING");
    // Log.d(TAG, "X=[" + x1 + "] Y=[" + y1 + "]");
    // Log.d(TAG, "PLAYER X=[" + playerX + "] PLAYER Y=[" + playerY + "]");
    //
    // float slope = (y2 - y1) / (x2 - x1);
    // float angle = (float) Math.atan(slope);
    //
    // c = y1 - (slope * x1);
    //
    // /**
    // * bottom right to left top
    // */
    // if (x1 > x2 && y1 > y2) {
    // sx = GameActivity.CAMERA_WIDTH;
    // sy = (slope * GameActivity.CAMERA_HEIGHT) + c;
    // Vector2 vel = Vector2Pool.obtain(new Vector2(-(float) (300 *
    // (Math.cos(angle))), -(float) (300 * (Math.sin(angle)))));
    // body.setLinearVelocity(vel.x, vel.y);
    // Vector2Pool.recycle(vel);
    // }
    // /**
    // * left top corner to right
    // */
    // else if (x2 > x1 && y2 > y1) {
    // sx = -100;
    // sy = (slope * sx) + c;
    // Vector2 vel = Vector2Pool.obtain((float) (150 * (Math.cos(angle))),
    // (float) (150 * (Math.sin(angle))));
    // body.setLinearVelocity(vel.x, vel.y);
    // Vector2Pool.recycle(vel);
    // }
    // /**
    // * left bottom corner to right up
    // */
    // else if (x2 > x1 && y1 > y2) {
    // sx = -100;
    // sy = (slope * sx) + c;
    // Vector2 vel = Vector2Pool.obtain((float) (150 * (Math.cos(angle))),
    // (float) (150 * (Math.sin(angle))));
    // body.setLinearVelocity(vel.x, vel.y);
    // Vector2Pool.recycle(vel);
    // }
    //
    // /**
    // * Right corner to left bottom down
    // */
    // else if (x1 > x2 && y2 > y1) {
    // sx = GameActivity.CAMERA_WIDTH;
    // sy = (slope * sx) + c;
    // Vector2 vel = Vector2Pool.obtain((float) (-150 * (Math.cos(angle))),
    // -(float) (300 * (Math.sin(angle))));
    // body.setLinearVelocity(vel.x, vel.y);
    // Vector2Pool.recycle(vel);
    // }
    // return true;
    // }
// }
